import React from "react";
import "./MenuBar.css";
import { Link, Outlet } from "react-router-dom";
import SideBarDropDown from "./SideBarDropDown";

import { Dropdown } from "react-bootstrap";

function MenuBar(props) {
  return (
    <>
    {/* <div className="main">
    <div className="container-fluid "> 
        <div className="row">
          <div className="col">
            <div className="logo-icon">
              <Link to="/hember">
                <i className="fa fa-bars" aria-hidden="true"></i>
              </Link>
            </div>
          </div> 
        </div> */}
         
        <div className="hmb">
            <Link to="/hember">
                <i className="fa fa-bars" aria-hidden="true"></i>
              </Link>
              </div>
         
     {/*    </div>
      </div> */}
      <SideBarDropDown></SideBarDropDown>
       <Outlet />
    </>
  );
}

export default MenuBar;
