import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';
function Peperpin(props) {
    return (
        <>
             <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>this perperin page so you pin it</p>
        </>
    );
}

export default Peperpin;