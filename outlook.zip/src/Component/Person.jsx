import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function Person(props) {
    return (
        <>
         <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>This is a person page so we are connect.This is a person page so we are connect </p>
         
        </>
    );
}

export default Person;