import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function PowerPoint(props) {
    return (
        <>
        <Header/>
        <FixMenu/>
        <MenuBar/>
        <p>Hello all welcome to POwer point file.Hello all welcome to POwer points file. </p>      
    </>
    );
}

export default PowerPoint;