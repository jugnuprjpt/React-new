import React from 'react';

function Skype(props) {
    return (
        <>
           THis is skype page 
        </>
    );
}

export default Skype;