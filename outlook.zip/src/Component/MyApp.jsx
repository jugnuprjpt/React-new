import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Outlook from './Outlook';
import MeetNow from './MeetNow';
import QrCode from './QrCode';
import Skype from './Skype';
import Msg from './Msg';
import Calender from './Calender';
import Person from './Person';
import Peperpin from './Peperpin';
import Check from './Check';
import WordFile from './WordFile.jsx';
import Xls from './Xls.jsx';
import PowerPoint from './PowerPoint.jsx';
import Ellipsis from './Ellipsis.jsx';
import Hember from './Hember.jsx';
/* import MenuBar from './MenuBar.jsx';
 */
function MyApp() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Outlook />} />
       <Route path="/MeetNow" element={<MeetNow />} />
       <Route path="/QrCode" element={<QrCode />} />
       <Route path="/Skype" element={<Skype />}/> 
      <Route path="/Msg" element={<Msg />}/> 
      <Route path="/Calender" element={<Calender />}/> 
      <Route path="/Person" element={<Person/>}/> 
      <Route path="/Peperpin" element={<Peperpin/>}/> 
      <Route path="/Check" element={<Check/>}/> 
      <Route path="/WordFile" element={<WordFile/>}/> 
      <Route path="/Xls" element={<Xls/>}/> 
      <Route path="/PowerPoint" element={<PowerPoint/>}/> 
      <Route path="/Ellipsis" element={<Ellipsis/>}/> 
      <Route path="/hember" element={<Hember/>}/> 

{/*       <Route path="/MenuBar" element={<MenuBar/>}/> 
 */}
        {/* <Route path="ClassComponenet" element={<ClassComponenet />}>
          <Route path="Construct" element={<ClassComponenetConstruct />} />
          <Route path="reusableClasscompo" element={<ClassComponenetReusable />}/>
          <Route path="stateexample" element={<StateExample />} />
          <Route path="statelifecycle" element={<StateLifeCycle />} />
          <Route path="loginPage" element={<LoginPage />} />
        </Route>

        <Route path="functionalCompo" element={<FunctionalComponenet />}>
          <Route path="functionhellojsrend"element={<MixFunctionComponent />} />
          <Route path="functionprops" element={<FunctionProps />} />
          <Route path="functionstatehooks" element={<FunctionStateHooks />}/>
          <Route path="FunctionUseEffectHooks" element={<FunctionUseEffectHooks />} />
          <Route path="FunctionUseEffectHooksJa"element={<FunctionUseEffectHooksJa />} />
          <Route path="FunctionUseLayoutEffectHook"element={<FunctionUseLayoutEffectHook />}/>
          <Route path="FunctionUseLayoutEffectHookPinakinsir"element={<FunctionUseLayoutEffectHookPinakinsir />}/>
          <Route path="FunctionUseLayouteffectusecontext"element={<FunctionUseLayoutEffectuseContext />}/>
          <Route path="FunctionUsesimpleApi"element={<FunctionUseSimpleApi />}/>
          <Route path="FunctionUseCallback"element={<FunctionUseCallBack />}/>
          <Route path="Functionusememo"element={<FunctionUseMemo />}/>
          <Route path="Functionuseref"element={<FunctionUseRef />}/>
          <Route path="Functionusereducer"element={<FunctionUseReducer />}/> */}
            
       {/*  </Route> */}

        {/* <Route path="stylecss" element={<StyleCssComponenet />}>
           <Route path="inlinecsscomponent" element={<InlineCssCompo />} />
        </Route> */}
     {/*  </Route> */}
    </Routes>
  </BrowserRouter>
  )
}

export default MyApp
