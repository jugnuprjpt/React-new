import React from "react";
import { Outlet, Link } from "react-router-dom";
import "./FixMenu.css";

function FixMenu(props) {
  return (
    <>
      <div className="fixMenu">
        <ul>
          {/* <a href="https://www.youtube.com/watch?v=V0O4pY2xX10"> */}

          <Link className="navbar-brand" to="/Msg">
            <li>
              <i class="fa-solid fa-envelope"></i>
            </li>
            {/*      </a> */}
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Calender">
            <li>
              <i class="fa-solid fa-calendar-days"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Person">
            <li>
              <i class="fa-solid fa-person"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Peperpin">
            <li>
              <i class="fa-solid fa-paperclip"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Check">
            <li>
              <i class="fa-solid fa-square-check"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/WordFile">
            <li>
              <i class="fa-solid fa-file-word"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Xls">
            <li>
              <i class="fa-solid fa-file-excel"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/PowerPoint">
            <li>
              <i class="fa-solid fa-file-powerpoint"></i>
            </li>
          </Link>
        </ul>
        <ul>
          <Link className="navbar-brand" to="/Ellipsis">
            <li>
              <i class="fa-solid fa-ellipsis"></i>
            </li>
          </Link>
        </ul>
      </div>
      <Outlet />
    </>
  );
}

export default FixMenu;
