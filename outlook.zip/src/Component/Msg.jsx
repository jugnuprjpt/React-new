import React from 'react';
import FixMenu from './FixMenu';
import Header from './Header';
import MenuBar from './MenuBar';

function Msg(props) {
    return (
        <>

            <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur, atque. Aliquid nobis veritatis facere provident ullam ipsa commodi. Nesciunt reiciendis sunt ipsum qui aliquam officia officiis quidem dolor ab ducimus.</p>
        </>
    );
}

export default Msg;