import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function Xls(props) {
    return (
        <>
            <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>Hello all welcome to Xls file.Hello all welcome to Xls file. </p>      
        </>
    );
}

export default Xls;