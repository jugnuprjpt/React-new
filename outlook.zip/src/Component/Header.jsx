import React from "react";
import "./Header.css";
import { MDBNavbar, MDBNavbarBrand, MDBNavbarToggler } from "mdbreact";
import { Link } from "react-router-dom";

function Header(props) {
  return (
    <>
      <nav class="navbar navbar-expand-lg navbar-light ">
        <div className="logo-icon">
          <i class="fa fa-bars" aria-hidden="true"></i>
        </div>
       {/*  <a className="navbar-brand" href="#">
          <b>Outlook</b>
        </a>  */}
         <Link className="navbar-brand" to="/">Outlook</Link> 
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="serach-icon">
          <form className="form-inline my-2 my-lg-0">
            {/* <i className="fa fa-search" aria-hidden="true"></i> */}
            <input
              className="form-control mr-sm-2"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />
          </form>
        </div>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item ">
            {/*  <a className="nav-link" href="#">  */}
          {/*   <Link className="navbar-brand" to="/">Outlook</Link> */} 
             <Link className="nav-link" to="/MeetNow">
               
                <i className="fa fa-video-camera" aria-hidden="true">
                  <small className="meet">Meet Now</small>
                </i>
                <span className="sr-only">(current)</span>
             </Link>
             {/*  <Link className="navbar-brand" to="/">Outlook</Link>  */}
             {/*  </a> */}
            </li>
            <li className="nav-item ">
             {/*  <a className="nav-link" href="#"> */}
             <Link className="nav-link" to="/QrCode">
                <i className="fa fa-qrcode" aria-hidden="true"></i>
                <span className="sr-only">(current)</span>
             {/*  </a> */}
             </Link>
            </li>
            <li className="nav-item ">
             {/*  <a className="nav-link" href="#"> */}
              <Link className="nav-link" to="/Skype">
                <i className="fa-brands fa-skype"></i>{" "}
                <span className="sr-only">(current)</span>
            {/*   </a> */}
            </Link>
            </li>
            <li className="nav-item ">
              <a
                className="nav-link"
                href="
            https://www.google.co.in"
              >
                
                <i className="fa fa-sticky-note" aria-hidden="true"></i>{" "}
                <span className="sr-only">(current)</span>
              </a>
            </li>

            <li className="nav-item ">
              <a className="nav-link" href="#">
                <i className="fa fa-calendar" aria-hidden="true"></i>{" "}
                <span className="sr-only">(current)</span>
              </a>
            </li>
            <li className="nav-item ">
              <a className="nav-link" href="#">
                <i className="fa-solid fa-bell"></i>{" "}
                <span className="sr-only">(current)</span>
              </a>
            </li>
            <li className="nav-item ">
              <a className="nav-link" href="#">
                <i className="fa fa-cog" aria-hidden="true"></i>{" "}
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="fa fa-question" aria-hidden="true"></i>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="fa-solid fa-bullhorn"></i>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="fa-solid fa-circle-user"></i>
              </a>
            </li>

            <li class="nav-item">
            
            </li>
          </ul>
        </div>
      </nav>
     
    </>
  );
}

export default Header;
