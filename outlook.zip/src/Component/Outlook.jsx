import React from "react";
import FixMenu from "./FixMenu";
import Header from "./Header";
import MenuBar from "./MenuBar";
import SideBarDropDown from"./SideBarDropDown"

function Outlook(props) {
  return (
    <>
     <Header />
     <FixMenu />
    {/*  <MenuBar /> */}
     
      <div className="container-fluid">
        <div className="row">
            <div className="col">
           {/*  <Header /> */}
            </div>
        </div>
        <div className="row">
          <div className="col">
           {/*  <FixMenu /> */}
          </div>
          <div className="col">
            <MenuBar />
          </div>
        </div>
      </div>
    </>
  );
}

export default Outlook;
