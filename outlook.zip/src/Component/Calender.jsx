import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function Calender(props) {
    return (
        <>
             <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>this is to much calender.this is to much calender .this is to much calender  </p>
        </>
    );
}

export default Calender;