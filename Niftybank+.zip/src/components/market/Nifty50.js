import React, { useRef, useState } from "react";
import { w3cwebsocket as W3CWebSocket } from "websocket";

const ws = new W3CWebSocket("ws://www.tradingcampus.net:17002");

function Nifty50() {
  const [index, setIndex] = useState();
  const [last, setLast] = useState(0.0);
  const [previous, setPrevious] = useState(0.0);
  const [percentage, setPercentage] = useState(0.0);
  const [color, setColor] = useState(0);
  const [oldPrice, newPrice] = useState(0);
  
  

  ws.onopen = () => {
    console.log("Connected");
  };

  ws.onmessage = (e) => {
    var narrowData = e.data.split("#");
    console.log(narrowData)

    if (narrowData[3] === "NIFTY 50") {
      
      setIndex(narrowData[3]);
      setPrevious(narrowData[5]);
      setPercentage(narrowData[6]);
      newPrice(narrowData[6]);

      if (newPrice > oldPrice) {
        
        setColor(1);
        setLast(narrowData[4]);
      } else {
        setColor(0);

        setLast(narrowData[4]);
      }
      oldPrice(newPrice)
      // console.log(oldPrice,newPrice);
    }
  };

  return (
    <>
      <td className="text-light">{index}</td>
      <td className={color == 1 ? "text-success" : "text-danger"}>{last}</td>
      <td className="text-light">{previous}</td>
      <td className={last - previous > 0 ? "text-success" : "text-danger"}>
        {parseFloat(last - previous).toFixed(4)}
      </td>
      <td className={percentage > 0 ? "text-success" : "text-danger"}>
        {percentage}
      </td>
    </>
  );
}

export default Nifty50;
