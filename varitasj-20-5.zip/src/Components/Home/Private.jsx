import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../Header/Header'

const Private = () => {
  return (
    <>
   {/*  <Header></Header> */}
    {/* <Link to="AboutUs">About Us</Link> */}

      
    </>
  )
}

export default Private
