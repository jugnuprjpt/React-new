import React from 'react'
import Header from '../Header/Header'

const Bike = () => {
  return (
    <>
      {/* <Header></Header> */}
    </>
  )
}

export default Bike
