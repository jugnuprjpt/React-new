import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

/* import Private from "./Home/Private";
import Health from "./Home/Health.jsx";
import Bike from "./Home/Bike.jsx";
import Commercial from "./Home/Commercial.jsx";
import Travel from "./Home/Travel.jsx"; */
import Home from "./Home/Home";
import Header from "./Header/Header";
import Health from "./Home/Health";
import Footer from "./Footer/Footer";
import HealthInsurance from "../Pages/Health/HealthInsurance/HealthInsurance";
import HealthFamilyDetail from "../Pages/Health/HealthFamilyDetail/HealthFamilyDetail";
/* import HealthInsurance from "./Health/HealthInsurance/HealthInsurance";
import HealthFamilyDetail from "./Health/HealthFamilyDetail/HealthFamilyDetail";
 */
import Main from "./Main/Main";


function MyAppRouting() {
  return (
    <>
      <BrowserRouter>
        <Header></Header>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="Health" element={<Health />}>
          </Route>
              <Route path="HealthInsurance" element={<HealthInsurance />}/>  
              <Route path="HealthFamilyDetail" element={<HealthFamilyDetail />}/>  
          {/* <Route path="GetQuote" element={<GetQuote />}/>  */}
         {/*  <Route path="Main" element={<Main />} /> */}
              
         
          {/*  <Route path="Private" element={<Private />} /> */}
          {/*  <Route path="AboutUs" element={<AboutUs />} /> */}
            {/* <Route path="Bike" element={<Bike />} /> */}
      
        </Routes>
        {/* <Route path="AboutUs" element={<AboutUs />} /> */}
        {/*  <Route path="Bike" element={<Bike/>} />
         <Route path="Commercial" element={<Commercial/>} />
         <Route path="Travel" element={<Travel/>} /> */}
         
      <Footer></Footer>
      </BrowserRouter>
    </>
  );
}

export default MyAppRouting;
