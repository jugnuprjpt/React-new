import './App.css';
import MyAppRouting from './Components/MyAppRouting';

function App() {
  return (
      <>
       
       <MyAppRouting/> 
         
      </>
    
  );
}

export default App;
