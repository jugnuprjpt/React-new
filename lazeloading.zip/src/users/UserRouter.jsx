import React from "react";
import { Routes, Route, Outlet, Link } from "react-router-dom";
import UserDashboard from "./UserDashboard.jsx";
import UserHeader from "./UserHeader.jsx";
import UsersProfile from "./UsersProfile.jsx";

function AdminRouter(props) {
  return (
    <>
      <Routes>
        <Route path="/" element={<UserHeader />}>
          <Route index element={<UserDashboard />} />
          <Route path="allusers" element={<UsersProfile />} />
        </Route>
      </Routes>
    </>
  );
}

export default AdminRouter;
