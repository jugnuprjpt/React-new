import React from 'react';

function Allusers(props) {
    return (
        <div>
           All Users Data 
        </div>
    );
}

export default Allusers;