import React from 'react';

function AdminHeader(props) {
    return (
        <div>
          Admin Header File  
        </div>
    );
}

export default AdminHeader;