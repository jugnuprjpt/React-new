import React from 'react'
import logo from '../../Assets/img/logo-wh.png'
import Header from '../Header/Header'
import Footer from '../Footer/Footer'

const GetQuote = () => {
  return (
    <>
    {/* <Header></Header> */}
     <div class="container-fluid commoncl healthbg healthdiv d-flex align-items-center justify-content-center">
    <div class="row flex-grow-1">
      <div class="col-12">
        <div class="container">
          <div class="row">
            <div class="col-12 col-xl-10 offset-xl-1 ">
              <div class="card commoncard">
                <div class="card-header d-flex justify-content-center align-items-center">
                  <a href="#" class="backbutton"><i class="fas fa-angle-double-left whtext"></i> <span
                      class="d-none d-md-inline-block">Back </span></a>
                  <h1>Health Insurance </h1>
                  <img src= {logo} alt=" " class="img-fluid whitelogo" />
                </div>
                <div class="card-body" ng-show="ShowTab">

                  <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">

                      <div class="btn-group btngp mb-3">
                        {/* <label class="btn   mb-0" ng-model="radioModel" uib-btn-radio="'Left'"
                          uncheckable>Individual</label> */}
                          <label class="btn mb-0 ng-untouched ng-valid ng-not-empty ng-dirty active ng-valid-parse" uib-btn-radio="'Individual'" ng-model="rdbPolicyType" id="Individual1" value="Individual" ng-click="ShowHideControls(rdbPolicyType)">Individual</label>
                        <label class="btn   mb-0" ng-model="radioModel" uib-btn-radio="'Middle'" uncheckable>Family
                          Floater</label>
                          
                      </div>

                    </div>
                  </div>

                  <div class="row">
                    <div class="col-12 d-flex justify-content-center ">
                      <div class="row lesspadding">

                        <div class="col-sm-6 col-lg-auto d-flex flex-column mb-3">



                          <div class="btn-group">
                            <label class="btn  maleicon mb-0 mr-2" ng-model="radioModel111" uib-btn-radio="'Left'"
                              uncheckable>Male</label>
                            <label class="btn  femaleicon mb-0" ng-model="radioModel111" uib-btn-radio="'Middle'"
                              uncheckable>Female</label>
                          </div>





                        </div>

                        <div class="col-sm-6 col-lg-auto mb-3">

                          <input type="text" class="form-control sm-custom-wid"/>

                          <span class="text-danger"> Error* </span>

                        </div>



                      </div>
                    </div>
                  </div>


                  <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">

                      <div class="btn-group btngp mb-3">
                        <label class="btn   mb-0" ng-model="radioModel11" uib-btn-radio="'Left'"
                          uncheckable>Basic</label>
                        <label class="btn   mb-0" ng-model="radioModel11" uib-btn-radio="'Middle'" uncheckable>Super
                          Top-Up</label>
                      </div>

                    </div>
                  </div>









                  <div class="row d-flex align-items-center justify-content-center">
                    <div class="col-12 col-md-auto mb-3">

                      <select class="custom-select customwid">
                        <option selected="" value="Service">Coverage Amount</option>
                      </select>

                    </div>
                  </div>

                  <div class="text-center pb-3">
                    <a href="#" class="orangebtn d-inline-block">Proceed</a>
                  </div>


               





                </div>

               

                <div class="card-footer text-center">Already Have Quotation? <a href="#" class="orangetext"
                    ng-click="quotation()"> Click here
                  </a></div>






              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 {/* <Footer></Footer> */}
    </>
  )
}

export default GetQuote
