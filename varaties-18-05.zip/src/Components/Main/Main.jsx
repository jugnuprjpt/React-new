
import React,{useState} from 'react'
import logo from '../../Assets/img/logo-wh.png'
import "./Main.css"
import { Link } from "react-router-dom";

const Main = () => {
    const [name, setName] = useState()
    const [email, setEmail] = useState()
    const [mobile, setMobile] = useState()
    const [otp, setOtp] = useState()
    const [nameRequired, setNameRequired] = useState(false)
    const [emailRequired, setEmailRequired] = useState(false)
    const [mobileRequired, setMobileRequired] = useState(false)
    const [otpRequired, setOtpRequired] = useState(false)

    
    const onSubmitHandler=()=>{
        console.log("clicked")
        if (name ==undefined) {
          setNameRequired(true)
        }
        else{
          setNameRequired(false)
        }
        if (email ==undefined) {
          setEmailRequired(true)
        }
        else{
          setEmailRequired(false)
        }
        if (mobile ==undefined) {
          setMobileRequired(true)
        }
        else{
          setMobileRequired(false)
        }
        if (otp ==undefined) {
          setOtpRequired(true)
        }
        else{
          setOtpRequired(false)
        } 
    }

  return (
    <>

        <div className="container-fluid commoncl carbg filldetail d-flex align-items-center justify-content-center">
    <div className="row flex-grow-1">
      <div className="col-12">
        <div className="container">
          <div className="row">
            <div className="col-12 col-xl-10 offset-xl-1 pt-3 pb-3 ">
              <div className="card commoncard ">
                <div className="card-header d-flex justify-content-center align-items-center">
                  <h1>Fill Your Details </h1>
                  <img src={logo} alt=" " className="img-fluid whitelogo" />
                </div>
                <div className="card-body">

                  <div className="form-container">

                     {/* ----------name------------ */}

                    <div className="form-group">
                      <input type="text" className={nameRequired==true ? "form-control text-center red" : " form-control text-center"} placeholder="Full Name"  onChange={(e) => setName(e.target.value)} />
                      <span className={nameRequired==true ? "visibleSpan" : "noneSpan"}>This Field is Required</span>
                    </div>

                    {/* -----------Email--------------- */}

                    <div className="form-group">
                      <input type="text" className={emailRequired==true ? "form-control text-center red" : " form-control text-center"} placeholder="Email" onChange={(e) => setEmail(e.target.value)}/>
                      <span className={emailRequired==true ? "visibleSpan" : "noneSpan"}>This Field is Required</span>
                    </div>

                    {/* ------------Mobile------------------ */}

                    <div className="form-group">
                      <input type="text"  className={mobileRequired==true ? "form-control text-center red" : " form-control text-center"} placeholder="Mobile No." onChange={(e) => setMobile(e.target.value)}/>
                      <span className={mobileRequired==true ? "visibleSpan" : "noneSpan"}>This Field is Required</span>
                    </div>

                    {/* ------------------OTP------------------ */}

                    <div className="form-group">
                      <input type="text"  className={otpRequired==true ? "form-control text-center red" : " form-control text-center"} placeholder="Enter OTP" onChange={(e) => setOtp(e.target.value)}/>
                      <span className={otpRequired==true ? "visibleSpan" : "noneSpan"}>This Field is Required</span>                    
                      </div>

                    {/* -----------------------GET OTP---------------- */}

                    <div className="row">
                      <div className="col-12 text-right mb-3">
                        <a href="#" className="orangetext underline"> Click here to get OTP </a>
                      </div>
                    </div>

                  </div>

                  <Link to="/GetQuote">
                  <div className="row">
                    <div className="col-12 text-center">
                     <button className="btn orangebtn mb-3 bigbutton" onClick={onSubmitHandler}> Get Quote </button> 
                    </div>
                  </div>
                  </Link>
                 
                 
                  

                  <p className="text-center">
                    By clicking on "Get Quote", you agree to our <a href="#" className="orangetext"> Privacy Policy </a> &
                    <a href="#" className="orangetext"> Terms of Use </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 
    </>
  )
}

export default Main
