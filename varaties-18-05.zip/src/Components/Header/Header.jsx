import React from 'react'
import logo from '../../Assets/img/logo.png'

function Header() {
  return (
    <nav className="navbar navbar-expand-md flex-wrap menu fixed-top innerpagemenu">
      
    <div className="row flex-grow-1">
      <div className="col-12">
        <div className="row">
          <div className="col-12 col-md-auto d-flex">
            <a className="navbar-brand order-md-1" href="#"><img src={logo} alt="" /></a>
            <button className="navbar-toggler ml-auto" type="button" data-toggle="collapse"
              data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false"
              aria-label="Toggle navigation"> <i className="fas fa-bars"></i> </button>
          </div>
          <div className="col-12 col-md flex-grow-1 d-flex align-items-center flex-column">
       
            <div className="d-flex flex-grow-1 w-100 flex-wrap ">
              <div className="collapse navbar-collapse  justify-content-center order-2 order-md-0" id="navbarsExampleDefault">
                <ul className="navbar-nav d-md-flex flex-md-wrap ">
                  <li className="nav-item"> <a className="nav-link" href="#" title="Our Partners &amp; Services">About Us</a>
                  </li>
                  <li className="nav-item"> <a className="nav-link" href="#" title="About Us">Register As a POS </a> </li>
                  <li className="nav-item"> <a className="nav-link" href="#" title="User Guide">User Guide </a> </li>
                  <li className="nav-item"> <a className="nav-link" href="#" title="Support"> Support </a></li>
                </ul>
              </div>
              <div className="order-0 order-md-1 ml-md-auto">
                <a href="#" className="orangebtn  text-nowrap mr-2 d-inline-block"> <img src="img/Login_Icon_1.png"
                    alt="" />
                  Join As PoSP </a>
                <a href="#" className="orangebtn text-nowrap d-inline-block"> <img src="img/Login_Icon_1.png" alt="" />
                  Login </a>

              </div>

              <div className="w-100 text-md-right order-1 order-md-2"> Loggedin as <span className="orangetext font-weight-bold"> XXXXXXXXX </span>,
                Pos code <span className="orangetext font-weight-bold">#00000 </span></div>

            </div>

          </div>
        </div>






      </div>
    </div>

  </nav>
  )
}

export default Header