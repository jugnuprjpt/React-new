import "./App.css";
import { Routes, Route } from "react-router-dom";
import Footer from "./Components/Footer/Footer";
import Header from "./Components/Header/Header";
import Main from "./Components/Main/Main";
import GetQuote from "./Components/Main/GetQuote.jsx";

function App() {
  return (
    <>
      <Header /> 

      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/GetQuote" element={<GetQuote />}></Route>
      </Routes>
     
      <Footer></Footer>
    </>
  );
}

export default App;
