// const store = createStore(reducer, applyMiddleware(thunkMiddleware));
// store.subscribe(() => {
//   console.log(store.getState());
// });
// store.dispatch(fetchUsers());