import React from 'react'
import Button from '../Button/Button'
import Header from '../Header/Header'
import SideBar from '../SideNavbar/SideBar'
import Market from '../ButtonMarket/Market'




function Home() {
  return (
      <>
      <Header/>
        <SideBar></SideBar>
        <Button></Button>
        <Market></Market>
      </>
  )
}

export default Home