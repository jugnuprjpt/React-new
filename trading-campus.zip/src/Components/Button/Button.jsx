import React from 'react'
import "./Button.css"

const Button = () => {
  return (
   
    <div className='container'>
     <span className='trade'>Trading</span> 
     
      <button type="button" className="btn btn-primary bt">Market Watch</button>
      <button type="button" className="btn btn-primary bt">Order Book</button>
      <button type="button" className="btn btn-primary bt">Trade Book</button>
      <button type="button" className="btn btn-primary bt">Position Book</button>
      <button type="button" className="btn btn-primary bt">Reports Book</button>
     

    </div>
   
  )
}

export default Button
