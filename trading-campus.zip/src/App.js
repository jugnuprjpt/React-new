import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Money from './Components/HeaderComponent/money.jsx'
import Home from './Components/Home/Home';


function App() {
  return (
    <div className="cont">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="money" element={<Money />}/>
        
        
      </Routes>
    </BrowserRouter>
    </div>
    
  );
}

export default App;
