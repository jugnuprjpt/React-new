import React from 'react'
import Button from '../Button/Button'
import Header from '../Header/Header'
import Sidebar from '../Sidebar/Sidebar'
// import Market from '../ButtonMarket/Market'




function Home() {
  return (
      <>
      <Header/>
      <Sidebar></Sidebar>
        <Button></Button>
        {/* <Market></Market> */}
      </>
  )
}

export default Home