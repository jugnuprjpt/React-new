import React, { useState } from "react";
import "./Sidebar.css";
import {
  FaDesktop,
  FaExchangeAlt,
  FaNetworkWired,
  FaToolbox,
  FaAccessibleIcon,
  FaVectorSquare,
} from "react-icons/fa";

function Sidebar() {
  const [open, setOpen] = useState(true);
  const [dropdownA, setDropdownA] = useState("");
  const [dropdownB, setDropdownB] = useState(""); 
  const [dropdownC, setDropdownC] = useState("");
  const [dropdownD, setDropdownD] = useState("");

  return (
    <>
      <div className="main">
        <div className="myContainer" onMouseLeave={() => setOpen(true)}>
          <div
            onClick={() => setOpen(false)}
            className={open === true ? "hamburg1" : "hamburg2"}
          >
            <i className="fa-solid fa-bars"></i>
          </div>
          {open === true ? (
            <div className="rowIcon">
              <div onClick={() => setOpen(false)} className="box">
                {<FaDesktop />}
              </div>
              <div onClick={() => setOpen(false)} className="box">
                {<FaExchangeAlt />}
              </div>
              <div onClick={() => setOpen(false)} className="box">
                {<FaNetworkWired />}
              </div>
              <div onClick={() => setOpen(false)} className="box">
                {<FaToolbox />}
              </div>
              <div onClick={() => setOpen(false)} className="box">
                {<FaAccessibleIcon />}
              </div>
              <div onClick={() => setOpen(false)} className="box">
                {<FaVectorSquare />}
              </div>
            </div>
          ) : (
            <div className="rowText">
              <div className="backText box">
                {<FaDesktop />} &nbsp; Dashboard
              </div>

              <div className="backText box" >
                {<FaExchangeAlt />} &nbsp; Trading
              </div>

              <div className="backText box" onClick={() => setDropdownA(true)}>
                {<FaNetworkWired />} &nbsp; Algo-studio
              </div>
              {dropdownA === true ? (
                <div className="link" onMouseLeave={() => setDropdownA(false)}>

                  <p>one leg strategy</p>
                  <p>Two leg strategy</p>
                  <p>Three leg strategy</p>
                  <p>Basket strategy 2</p>
                </div>
              ) : null}

              <div className="backText box" onClick={() => setDropdownB(true)}>
                {<FaToolbox />} &nbsp; Option Box
              </div>
              {dropdownB === true ? (
                <div className="link" onMouseLeave={() => setDropdownB(false)}>
                  <div className="fnt">
                  <p>Vol Trading</p>
                  <p>Greek Tracker</p>
                  <p>Two Leg Spread Matrix</p>
                  <p>Four Leg Spread Matrix</p>
                  <p>Option Strategy Box</p>
                  </div>
                </div>
              ) : null}

              <div className="backText box" onClick={() => setDropdownC(true)}>
                {<FaAccessibleIcon />} &nbsp; Technical studio
              </div>
              {dropdownC === true ? (
                <div className="link" onMouseLeave={() => setDropdownC(false)}>
                  <div className="fnt">
                  <p>MTChart</p>
                  </div>
                </div>
              ) : null}

              <div className="backText box" onClick={() => setDropdownD(true)}>
                {<FaVectorSquare />} &nbsp; Screeners
              </div>
              {dropdownD === true ? (
                <div className="link" onMouseLeave={() => setDropdownD(false)}>
                  <div className="fnt">
                  <p>Screener</p>
                  <p>Customize Screener</p>
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Sidebar;
