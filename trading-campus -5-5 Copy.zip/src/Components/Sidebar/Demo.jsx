import React, { useState } from "react";

function Demo() {
  const [open1, setOpen1] = useState("");
  const [open2, setOpen2] = useState("");

  return (
    <>
      <div>
        <button onClick={() => setOpen1(true)}>Click Here</button>
        {open1 == true ? (
          <div onMouseLeave={() => setOpen1(false)}>
            <div>Link 1</div>
            <div>Link 2</div>
            <div>Link 3</div>
          </div>
        ) : null}
      </div>
      <div>
        <button onClick={() => setOpen2(true)}>Click Here</button>
        {open2 == true ? (
          <div onMouseLeave={() => setOpen2(false)}>
            <div>Link 1</div>
            <div>Link 2</div>
            <div>Link 3</div>
          </div>
        ) : null}
      </div>
    </>
  );
}

export default Demo;
