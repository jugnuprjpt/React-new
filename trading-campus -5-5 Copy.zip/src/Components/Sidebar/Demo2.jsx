import React, {useState} from 'react'
import "./ham.css"

function Demo2() {
    const [open, setOpen] = useState("");
  return (
<>
<button onClick={()=>setOpen(true)}>Click here</button>
<div className={open == true ? "open" : "close"}>
    Hello World
</div>
</>
  )
}

export default Demo2