/**
 *
 * Page404
 *
 */

import React from "react";
import { Link } from "react-router-dom";

const Page404 = (props) => {
  return (
    <>
      <div className="page-404">
        The page you are looking for was not found.
      </div>
      <Link to="/">
        <h1>Go to home page</h1>
      </Link>
    </>
  );
};

export default Page404;
