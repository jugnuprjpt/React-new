import React, { useState } from "react";


function ClickName() {
  const [data, setDate] = useState("Jugnu");

  function updata () {
            setDate("Rekha")
  }
  return (
    <div>
      <h1> {data}</h1>
      <button onClick={updata}> Click-me</button>
    </div>
  );
}
export default ClickName;
