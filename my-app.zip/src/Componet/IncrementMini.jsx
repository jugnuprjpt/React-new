import React from "react";

class IncrementMini extends React.Component {
  constructor() {
    super();
    this.state = {
      data: 25,
    };
  }
  render() {
    return (
      <div>
        <p>Welcome to Class-this component</p>
        <button
          onClick={() => {
            if (this.state.data > 0) {
              this.setState({ data: this.state.data - 25 });
            }
          }}
        >
          Decrement
        </button>
        <h1>{this.state.data}</h1>
        <button onClick={() => this.setState({ data: this.state.data + 25 })}>
          Increment
        </button>
      </div>
    );
  }
}
export default IncrementMini;
