import React from "react";
import { useState } from "react";
import img from "../Boom.gif";

function ClickImage() {
  const [data, setState] = useState(false);
  return (
    <div>
      {data ? (
        <img src={img} style={{ width: "300px", height: "300px" }} />
      ) : (
        "jugnu"
      )}
      <br />
      <button onClick={() => setState(true)}>Click and Boom</button>
    </div>
  );
}
export default ClickImage;
