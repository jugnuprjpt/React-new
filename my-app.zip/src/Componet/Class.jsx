import React from "react";
import { render } from "react-dom";

class Class extends React.Component{

    constructor()
    {
        super();
    }

render()
{
    return(
        <div>
            <h1>Hello all my friend welcome to CLASS</h1>
        </div>
    )
}
}
export default Class