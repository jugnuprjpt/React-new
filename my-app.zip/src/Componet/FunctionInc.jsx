import React, { useState } from "react";

function FunctionInc() {
  let [data, setData] = useState(1);
  return (
    <div>
      <p>Welcome to Class-this component</p>
      <button onClick={() => setData(--data)}>Decrement</button>
      <h1>{data}</h1>
      <button onClick={() => setData(++data)}>Increament</button>
    </div>
  );
}

export default FunctionInc;
