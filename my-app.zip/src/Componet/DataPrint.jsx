import React from "react";
import { useState } from "react";

function DataMost() {
  const [data, setData] = useState(null);

  function GetData(val) {
    setData(val.target.value);
  }
  return (
    <div>
      <h1>{data}</h1>
      <input type="text" onChange={GetData} />
      <h1>TYPE IN BOX</h1>
    </div>
  );
}

export default DataMost;
