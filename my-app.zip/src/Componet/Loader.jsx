import React, { useState } from "react";
import "../App.css";
//import logo from ../logo.//

const image = { width: "200px", height: "200px" };

function App() {
  const [isLoading, setLoading] = useState(false);

  const fetchdata = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 5000);
  };
  return (
    <div className="App">
      <header className="App-header">
        {" "}
        <br />
        {isLoading ? (
          ""
        ) : (
          <button className="button" onClick={fetchdata}>
            click-me
          </button>
        )}
        {isLoading ? (
          <div>
            <h4>Fetchning your data</h4>
            <img style={image} src={require("../logo.svg").default} />{" "}
          </div>
        ) : (
          ""
        )}
      </header>
    </div>
  );
}

export default App;
