import { render } from "@testing-library/react";
import React from "react";

class MapFunction extends React.Component {
  constructor() {
    super();
    this.state = {
      list: [
        { Name: "Jugnu", Phone: "46546546", email: "jbp@gmail.com" },
        { Name: "Mitesh", Phone: "121325456", email: "Mpp@gmail.com" },
        { Name: "Khemchand", Phone: "858556565", email: "Khp@gmail.com" },
        { Name: "Vishnu", Phone: "82565215254", email: "khp@gmail.com" },
      ],
    };
  }
  render() {
    return (
      <div>
        <h1>Listing of Mapping:- </h1>
        {this.state.list.map((item) => (
          <div>
            <span> Name:{item.Name}</span>
            <span> Mail:{item.email}</span>
          </div>
        ))}
      </div>
    );
  }
}
export default MapFunction;
