import React from "react";

function MatRow() {
  function OnTouch() {
    alert("On-Touch");
  }

  return (
    <div>
      <h1>Here shown demo example</h1>
      <button onClick={OnTouch}>On-touch-shown on pop-up</button>
    </div>
  );
}

export default MatRow;
