const howToUseApp = [
    {
      id: 1,
      title: "Sign in",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, Etquia quis?Lorem ipsum,  Etquia quis?",
    },
    {
      id: 2,
      title: "Add your bank Account",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit.",
    },
    {
      id: 3,
      title: "Send payment request",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, consectetur adipisicing elit. Etquia quis?Lorem ipsum?",
    },
  ];
  
  export default howToUseApp;
  