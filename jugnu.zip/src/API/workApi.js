const workapi = [
    {
      id: 1,
      logo: "fas fa-download",
      title: "Downlaod App",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 2,
      logo: "fas fa-chalkboard-teacher",
      title: "Complete the Instruction ",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 3,
      logo: "fas fa-donate",
      title: "Receive your funds",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
  ];
  
  export default workapi;