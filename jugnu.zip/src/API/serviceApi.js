const serviceapi = [
    {
      id: 1,
      logo: "fas fa-download",
      title: "Register for free.",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 2,
      logo: "fas fa-user-check",
      title: "Verify your identity ",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 3,
      logo: "fas fa-money-check-alt",
      title: "Add recipient's bank details.",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 4,
      logo: "fab fa-amazon-pay",
      title: "Pay for your transfer.",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 5,
      logo: "fas fa-hand-holding-usd",
      title: "choose an amount to send.",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
    {
      id: 6,
      logo: "fas fa-globe",
      title: "That's it.",
      info: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Etquia quis?",
    },
  ];
  
  export default serviceapi;
  