import React from 'react';
import Navbar from './Navbar';
import Header from './Header';
import HowItwork from './HowItwork';
import Aboutus from './Aboutus';
import Services from './Services';
import Contact from './Contacts';
import Footer from './Footer';

const Home =() => {
  return (
    <>
      <Navbar/>
      <Header/>
      <HowItwork/>
      <Aboutus/>
      <Services/>
      <Contact/> 
      <Footer/>
      
    </>
  );
}

export default Home;