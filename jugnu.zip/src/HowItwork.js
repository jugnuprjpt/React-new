import React, { useState } from 'react'
import workapi from './API/workApi'
const HowItwork = () => {

    // const workData=workapi
    const [workData,setWorkData] = useState(workapi)
  return (
        <>
        <section>
            <div className='work-container container'>
                <h1 className='main-heading text-center'>How does it work</h1>
                <div className='row'>
                    {workData.map((item, index)=> (
                            <div className="col-12 col-lg-4 text-center work-container-subdiv" key={index} >
                              <i class={`fontawesome-style ${item.logo}`}></i>
                              <h2 className="sub-heading">{item.title}</h2>
                              <p className="main-hero-para w-100">
                               {item.info}
                              </p>
                            </div>
                        
                    ))}
                   
 
                </div>
            </div>
        </section>
        </>
  )
}

export default HowItwork