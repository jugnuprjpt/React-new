import React from 'react';
import { useCookies } from 'react-cookie';
import { Routes, Route, Outlet, Link } from "react-router-dom";
import AdminDashboard from "./AdminDashboard.jsx";
import AllUsersData from "./AllUsersData.jsx";

function AdminRouter(props) {
    const [cookies, setCookie] = useCookies([]);
    return (
        <>
           
            <Routes>
                <Route path="/" element={<AdminDashboard />}>
                    <Route path="allusers" element={<AllUsersData />} />
                </Route>
            </Routes>
        </>
    );
}

export default AdminRouter;