import React, { useEffect, useState } from 'react';
import {
    MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBDropdown,
    MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem, MDBIcon
} from "mdbreact";
import { BrowserRouter as Router, Link } from "react-router-dom";
import SideBar from './SideBar';
import './sidebar.css';
import { retierveUsers } from '../actions/users';
import { useDispatch, useSelector } from 'react-redux';
function HeaderMenu(props) {
    const [SideMenuOpenClose, setSideMenuOpenClose] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const [username, setUserName] = useState('test');
    // const users = useSelector(state => state.users);
    // const dispatch = useDispatch();
    // useEffect(()=>{
    //     console.log("useEffect Called");
    //     dispatch(retierveUsers())
    //     console.log(users.data.Data[0].fullname);
    //     // setUserName(users.data.Data[0].fullname);
    // },[])
    
    const toggleCollapse = () => {
        setSideMenuOpenClose(!SideMenuOpenClose);
    }
    return (
        <>
            <header>
            <SideBar/>
                    <MDBNavbar color="default-color" dark expand="md">
                       
                        <MDBCollapse id="navbarCollapse3" isOpen={isOpen} navbar>
                        <MDBNavbarToggler />
                            <MDBNavbarNav left>
                                <MDBNavItem>
                                    <Link className='nav-link' to="/">Home</Link>
                                </MDBNavItem>
                            </MDBNavbarNav>
                            <MDBNavbarNav right>
                                <MDBDropdown>
                                    <MDBDropdownToggle nav caret>
                                        <span className="mr-2"></span>
                                    </MDBDropdownToggle>
                                    <MDBDropdownMenu>
                                        <MDBDropdownItem href="#!">Action</MDBDropdownItem>
                                        <MDBDropdownItem href="#!">Another Action</MDBDropdownItem>
                                        <MDBDropdownItem href="#!">
                                            Something else here
                                        </MDBDropdownItem>
                                        <MDBDropdownItem href="/logout">
                                            Logout
                                        </MDBDropdownItem>
                                    </MDBDropdownMenu>
                                </MDBDropdown>
                            </MDBNavbarNav>
                        </MDBCollapse>
                    </MDBNavbar>
            </header>
        </>
    );
}

export default HeaderMenu;