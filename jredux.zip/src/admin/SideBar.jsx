import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './sidebar.css';

function SideBar(props) {
    const [isOpenMenu, setIsOpenMenu] = useState(false);
    const toggleCollapseMenu = () => {
        console.log(isOpenMenu);
        setIsOpenMenu(!isOpenMenu);
    }
    return (
        <>
            <div className="mainmenu">
                <div id='sidemenu' className={isOpenMenu ? 'sidebar' : ''}>
                    {/* test */}
                    {/* <i onClick={toggleCollapseMenu} className='fa fa-times posi-close'></i> */}
                    <div class="row cf">
                        <div class="three col">
                            <div className={isOpenMenu ? 'hamburger is-active posi-close' : 'hamburger posi-close'} onClick={toggleCollapseMenu} id="hamburger-1">
                                <span class="line"></span>
                                <span class="line"></span>
                                <span class="line"></span>
                            </div>
                        </div>

                    </div>
                    <div className="menu">
                        <ul>
                            <li className='nav-items'><Link to="admin">Dashboard</Link></li>
                            <li className='nav-items'><Link to="users">All Users</Link></li>
                        </ul>
                    </div>
                </div>
            </div>
        </>
    );
}

export default SideBar;