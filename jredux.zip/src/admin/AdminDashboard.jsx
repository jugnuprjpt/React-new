import React from 'react';
import HeaderMenu from './HeaderMenu';

function AdminDashboard(props) {
    return (
        <>
            <HeaderMenu />
            AdminDashboard
        </>
    );
}

export default AdminDashboard;