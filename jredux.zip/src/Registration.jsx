import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardText, MDBCardTitle, MDBCol, MDBInput } from 'mdbreact';
import React, { useState } from 'react';
import { useCookies } from 'react-cookie'
import { Link, useNavigate } from "react-router-dom";
import Header from './Header';
import FooterData from './Footer';
import './registration.css';
import 'react-dropzone-uploader/dist/styles.css'
import Dropzone from 'react-dropzone-uploader'
import { getDroppedOrSelectedFiles } from 'html5-file-selector'
import axios from 'axios';


function Login(props) {
    // const [cookies, setCookie] = useCookies([])
    // const [state, setState] = useState({});
    const [fileData, setFileData] = useState({});
    const [allData, setallData] = useState({});
    const navigate = useNavigate();
    function submitData(e) {
        e.preventDefault();
        // const data = new FormData()
        // data.append('file', fileData)
        // let file = [ {'profilepic':fileData}];
        // console.log(file);
        // setallData({ ...allData, file });
        // console.log(fileData);
        // console.log("allData",allData);

        // // console.log(allFiles);
        // const data = new allData() 
        // data.append('file', file)
        // return false;
        // console.log(fileData);
        const data = new FormData()
        data.append('file', fileData)

        axios.post("http://localhost/API/img-upload",data).then(res => { // then print response status
            console.warn(res);
        })

        axios.post("http://localhost/API/registration", allData).then(res => { // then print response status
            console.warn(res);
            if (res.data) {
                navigate("/login");
            }
        })
    }
    const onSubmit = (files, allFiles) => {
        console.log(allFiles);
        // allFiles.forEach(f => f.remove())
    }
    const selectFileInput = ({ accept, onFiles, files, getFilesFromEvent }) => {
        const textMsg = files.length > 0 ? 'Upload Again' : 'Select Files'
        return (
            <label className="btn btn-danger mt-4">
                {textMsg}
                <input
                    style={{ display: 'none' }}
                    type="file"
                    accept={accept}
                    multiple
                    onChange={e => {
                        getFilesFromEvent(e).then(chosenFiles => {
                            onFiles(chosenFiles)
                        })
                    }}
                />
            </label>
        )
    }
    const getFilesFromEvent = e => {
        return new Promise(resolve => {
            getDroppedOrSelectedFiles(e).then(chosenFiles => {
                resolve(chosenFiles.map(f => f.fileObject))
            })
        })
    }
    const fileParams = ({ meta }) => {
        return { url: 'https://httpbin.org/post' }
    }
    const onFileChange = ({ meta, file }, status) => {
        // setallData({ ...allData, file });
        setFileData(file)
        // let url = "http://localhost/api/img-upload";

        // axios.post(url, data).then(res => { // then print response status
        //     console.warn(res);
        // })
    }
    return (

        <>
            <Header />
            <div className="container">
                <div className="form_wrapper">
                    <div className="form_container">
                        <div className="title_container">
                            <h2>Responsive Registration Form</h2>
                        </div>
                        <div className="row clearfix">
                            <div className="">
                                <form onSubmit={submitData}>
                                    <div className="input_field"> <span><i aria-hidden="true" className="fa fa-user"></i></span>
                                        <input type="text" name="username" placeholder="User Name" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} required />
                                    </div>
                                    <div className="input_field"> <span><i aria-hidden="true" className="fa fa-envelope"></i></span>
                                        <input type="email" name="email" placeholder="Email" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} required />
                                    </div>
                                    <div className="input_field"> <span><i aria-hidden="true" className="fa fa-lock"></i></span>
                                        <input type="password" name="password" placeholder="Password" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} required />
                                    </div>
                                    <div className="input_field"> <span><i aria-hidden="true" className="fa fa-lock"></i></span>
                                        <input type="password" name="cpassword" placeholder="Re-type Password" required />
                                    </div>
                                    <div className="input_field"> <span><i aria-hidden="true" className="fa fa-mobile"></i></span>
                                        <input type="text" name="mobile" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} placeholder="Mobile Number" required />
                                    </div>
                                    <div className="row clearfix">
                                        <div className="col_half">
                                            <div className="input_field"> <span><i aria-hidden="true" className="fa fa-user"></i></span>
                                                <input type="text" name="fname" placeholder="First Name" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} />
                                            </div>
                                        </div>
                                        <div className="col_half">
                                            <div className="input_field"> <span><i aria-hidden="true" className="fa fa-user"></i></span>
                                                <input type="text" name="lname" placeholder="Last Name" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} required />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="input_field radio_option">
                                        <input type="radio" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} name="gender" id="rd1" value="Male" />
                                        <label htmlFor="rd1">Male</label>
                                        <input type="radio" onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} name="gender" id="rd2" value="Female" />
                                        <label htmlFor="rd2">Female</label>
                                    </div>
                                    <div className="input_field select_option">
                                        <select onChange={(e) => {
                                            setallData({ ...allData, [e.target.name]: e.target.value });
                                        }} name="city">
                                            <option>Select a City</option>
                                            <option value="1">Ahmedabad</option>
                                            <option value="2">Surat</option>
                                        </select>
                                        <div className="select_arrow"></div>
                                    </div>
                                    <div className="input_field checkbox_option">
                                        <input type="checkbox" id="cb1" />
                                        <label htmlFor="cb1">I agree with terms and conditions</label>
                                    </div>
                                    <div className="input_field checkbox_option">
                                        <input type="checkbox" id="cb2" />
                                        <label htmlFor="cb2">I want to receive the newsletter</label>
                                    </div>
                                    <div className="input_field">
                                        <Dropzone
                                            onSubmit={onSubmit}
                                            onChangeStatus={onFileChange}
                                            InputComponent={selectFileInput}
                                            getUploadParams={fileParams}
                                            getFilesFromEvent={getFilesFromEvent}
                                            accept="image/*,audio/*,video/*"
                                            maxFiles={5}
                                            inputContent="Drop A File"
                                            styles={{
                                                dropzone: { width: '100%', height: '100%' },
                                                dropzoneActive: { borderColor: 'green' },
                                            }}
                                        />
                                    </div>
                                    <input className="button" type="submit" value="Register" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <FooterData/>
        </>
    );
}

export default Login;