import React from "react";
import CommonMenu from "./commonmenu"
function Footer(props) {
  return (
    <>
      <ul>
          <CommonMenu/>
      </ul>
    </>
  );
}

export default Footer;
