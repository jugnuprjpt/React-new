import React, { useEffect, useState } from "react";
import {
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarNav,
  MDBNavItem,
  MDBNavLink,
  MDBNavbarToggler,
  MDBCollapse,
  MDBFormInline,
  MDBDropdown,
  MDBDropdownToggle,
  MDBDropdownMenu,
  MDBDropdownItem,
} from "mdbreact";
// import { Link } from 'react-router-dom';
import CommonMenu from "./commonmenu";
import { useCookies } from "react-cookie";
import { Link } from "react-router-dom";

export default function Header() {
  const [showBasic, setShowBasic] = useState(false);
  // const MenuData = ["Home", "About", "Contact", "Login"];
  // const MenuData = {"/":"Home", "/about":"About", "/users":"Users","/contact":"Contact", "/admin":"admin"};
  const [cookies, setCookie] = useCookies([]);
  // console.log(doubled);
  // console.log(cookies.isLogin);
  var LoginLouout = "";
  if (cookies.isLogin === "") {
    LoginLouout =
      <>
        <li className="nav-item" >
          <Link className="nav-link" to="login">
            Login
          </Link>
        </li>
      </>
  } else {
    LoginLouout = 
      <>
       <li className="nav-item" >
          <Link className="nav-link" to="logout">
            Profile
          </Link>
        </li>
       <li className="nav-item" >
          <Link className="nav-link" to="logout">
            OtherData
          </Link>
        </li>
       <li className="nav-item" >
          <Link className="nav-link" to="logout">
            Logout
          </Link>
        </li>
      </>
   }
  return (
    <MDBNavbar color="indigo" dark expand="md">
      <MDBNavbarBrand>
        <strong className="white-text">Navbar</strong>
      </MDBNavbarBrand>
      <MDBNavbarToggler />
      <MDBCollapse id="navbarCollapse3" navbar>
        <MDBNavbarNav left>
          <CommonMenu />
          {LoginLouout}
        </MDBNavbarNav>
        <MDBNavbarNav right>right side</MDBNavbarNav>
      </MDBCollapse>
    </MDBNavbar>
  );
}
