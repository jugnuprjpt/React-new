import React from 'react';
import { render } from "react-dom";
// import App from "./App";
import Home from "./Home.jsx";
import About from "./About.jsx";
import Login from "./Login.jsx";
import Registration from "./Registration.jsx";
import Logout from "./Logout.jsx";
// import Contact from "./Contact.jsx";
// import HeaderMenu from './HeaderMenu';
import { Routes, Route, Outlet, Link } from "react-router-dom";


const UserRouter = React.lazy(() => import("./users/UserRouter"));
const AdminRouter = React.lazy(() => import("./admin/AdminRouter"));

// import your route components too
function MainRouter(props) {
    return (
        <>
        
            <Routes>
                <Route path="/" element={<Home />}></Route>
                <Route path="/about" element={<About />}></Route>
                <Route path="/login" element={<Login />} />
                <Route path="/logout" element={<Logout />} />
                <Route path="/registration" element={<Registration />} />
                    <Route
                        path="users/*"
                        element={
                            <React.Suspense fallback={<>...</>}>
                                <UserRouter />
                            </React.Suspense>
                        }
                    />
                    <Route
                        path="admin/*"
                        element={
                            <React.Suspense fallback={<>...</>}>
                                <AdminRouter />
                            </React.Suspense>
                        }
                    />
                    <Route path="*" element={<NoMatch />} />
                
            </Routes>
        </>
    );
}

function NoMatch() {
    return (
      <div>
        <h2>Nothing to see here!</h2>
        <p>
          <Link to="/">Go to the home page</Link>
        </p>
      </div>
    );
  }
export default MainRouter;