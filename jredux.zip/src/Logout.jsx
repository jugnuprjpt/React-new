import React, { useEffect } from "react";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";

function Logout(props) {
  const [cookies, setCookie] = useCookies([]);
  setCookie("isLogin", "", -3600);
  setCookie("userid", "", -3600);
  const navigate = useNavigate();
  useEffect(() => {
    navigate("/login");
  });
  return <></>;
}

export default Logout;
