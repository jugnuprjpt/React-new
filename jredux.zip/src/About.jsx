import React from 'react';
import Header from './Header';

function About(props) {
    return (
        <>
            <Header />
            <div className="container">
                <div className="row">
                    <div className="col">

                        <h2>About us Page Data</h2>
                    </div>
                </div>
            </div>
        </>
    );
}

export default About;