import React from "react";
import { Link } from "react-router-dom";

function commonmenu(props) {
  const MenuData = { "/": "Home", "/about": "About" };
  // const doubled = MenuData.map((MenuItem) => { return <><li>{MenuItem}</li></>});
  const doubled = Object.entries(MenuData).map((MenuItem, index) => {
    return (
      <li className="nav-item" key={index}>
        <Link className="nav-link" key={index} to={MenuItem[0]}>
          {MenuItem[1]}
        </Link>
      </li>
    );
  });
  return <>{doubled}</>;
}

export default commonmenu;
