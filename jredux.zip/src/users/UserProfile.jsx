import React from 'react';

function UserProfile(props) {
    return (
        <div>
            UserProfile
        </div>
    );
}

export default UserProfile;