import React from 'react';
import { Routes, Route, Outlet, Link } from "react-router-dom";
import UserDashboard from "./UserDashboard.jsx";
import UserProfile from "./UserProfile.jsx";

function AdminRouter(props) {
    return (
        <>
            <Routes>
                <Route path="/" element={<UserDashboard />}>
                    <Route path="profile" element={<UserProfile />} />
                </Route>
            </Routes>
        </>
    );
}

export default AdminRouter;