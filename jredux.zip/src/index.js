import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';
import MainRouter from './router';
import { createRoot } from "react-dom/client";
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import storeData from './store.jsx';
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
console.log("main entry Index calling");

root.render(
<Provider store={storeData}>
<BrowserRouter>
    <MainRouter />
  </BrowserRouter>
</Provider>
);
