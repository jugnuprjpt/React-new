import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Header from './Header';
import { retierveUsers } from './actions/users';
function Home(props) {
    // const users = useSelector(state => state.users);
    // const dispatch = useDispatch();
    console.log("Home Called");
    // useEffect(()=>{
    //     console.log("useEffect Called");
    //     dispatch(retierveUsers())
    // },[])
    return (
        <>
        <Header/>
        Home Data
        {/* {JSON.stringify(users)} */}
            Home page
        </>
    );
}

export default Home;