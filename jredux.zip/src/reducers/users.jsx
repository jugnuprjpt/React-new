import { RETRIEVE_USER } from "../actions/type.jsx"
const initialState = []
const userReceducer = (users = initialState, action) => {
    console.log("userReceducer user.jsx called");
    const { type, payload } = action;
    switch (type) {
        case RETRIEVE_USER:
            console.log("userReceducer case RETRIEVE_USER");
            return payload

        default:
            return users

    }
}

export default userReceducer;