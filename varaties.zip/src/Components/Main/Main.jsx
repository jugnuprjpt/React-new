import { toBeRequired } from '@testing-library/jest-dom/dist/matchers'
import React,{useState} from 'react'
import logo from '../../Assets/img/logo-wh.png'
import "./Main.css"

const Main = () => {
    const [name, setName] = useState()
    const [valueRequired, setValueRequired] = useState(false)

    

    const onSubmitHandler=()=>{
        console.log("clicked")
        if (name==undefined) {
            setValueRequired(true)
        }
    }

    
    // console.log(name)
  return (
    <>

    
        <div className="container-fluid commoncl carbg filldetail d-flex align-items-center justify-content-center">
    <div className="row flex-grow-1">
      <div className="col-12">
        <div className="container">
          <div className="row">
            <div className="col-12 col-xl-10 offset-xl-1 pt-3 pb-3 ">
              <div className="card commoncard ">
                <div className="card-header d-flex justify-content-center align-items-center">
                  <h1>Fill Your Details </h1>
                  <img src={logo} alt=" " className="img-fluid whitelogo" />
                </div>
                <div className="card-body">

                  <div className="form-container">

                    <div className="form-group">
                      <input type="text" className={valueRequired==true ? "form-control text-center red" : " form-control text-center"} placeholder="Full Name"  onChange={(e) => setName(e.target.value)} />
                      <span className={valueRequired==true ? "visibleSpan" : "noneSpan"}>This Field is Required</span>
                    </div>
                    <div className="form-group">
                      <input type="text" className="form-control text-center" placeholder="Email"/>
                    </div>
                    <div className="form-group">
                      <input type="text" className="form-control text-center" placeholder="Mobile No."/>
                    </div>
                    <div className="form-group">
                      <input type="text" className="form-control text-center" placeholder="Enter OTP"/>
                    </div>

                    <div className="row">
                      <div className="col-12 text-right mb-3">
                        <a href="#" className="orangetext underline"> Click here to get OTP </a>
                      </div>
                    </div>

                  </div>

                  <div className="row">
                    <div className="col-12 text-center">
                      <button className="btn orangebtn mb-3 bigbutton" onClick={onSubmitHandler}> Get Quote </button>
                    </div>
                  </div>

                  <p className="text-center">
                    By clicking on "Get Quote", you agree to our <a href="#" className="orangetext"> Privacy Policy </a> &
                    <a href="#" className="orangetext"> Terms of Use </a>
                  </p>


                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    </>
  )
}

export default Main
