import logo from './logo.svg';
import './App.css';
import { Products } from './components/products';

function App() {
  return (
    <div className="App">
      <Products />
    </div>
  );
}

export default App;
