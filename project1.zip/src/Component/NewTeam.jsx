import React from 'react';
import Header from './Header';

function NewTeam(props) {
    return (
        <>
           <Header/>
            <h1>Hello my dear</h1>

        </>
    );
}

export default NewTeam;