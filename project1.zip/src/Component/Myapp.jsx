import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home.jsx";
import About from "./About.jsx";
import Contact from "./Contact.jsx";
import Example from "./Example.jsx";
/* import NewTeam from './NewTeam.jsx'; */
import ClassComponenet from "./ClassCompo/ClassComponenet.jsx";
import FunctionalComponenet from "./FunctionalCompo/functionalComponenet.jsx";
import ClassComponenetConstruct from "./ClassCompo/ClassComponenetConstruct.jsx";
import ClassComponenetReusable from "./ClassCompo/ClassComponenetReusable.jsx";
import StateExample from "./ClassCompo/StateExample.jsx";
import StateLifeCycle from "./ClassCompo/StateLifeCycle.jsx";
import LoginPage from "./ClassCompo/LoginPage.jsx";
import StyleCssComponenet from "./ClassCompo/StyleCssComponenet.jsx";
import InlineCssCompo from "./ClassCompo/InlineCssCompo.jsx";
import MixFunctionComponent from "./FunctionalCompo/MixFunctionComponent.jsx";
import FunctionProps from "./FunctionalCompo/FunctionProps.jsx";
import FunctionStateHooks from "./FunctionalCompo/FunctionStateHooks.jsx";
import FunctionUseEffectHooks from "./FunctionalCompo/FunctionUseEffectHooks.jsx";
import FunctionUseEffectHooksJa from "./FunctionalCompo/FunctionUseEffectHooksJa.jsx";
import FunctionUseLayoutEffectHook from "./FunctionalCompo/FunctionUseLayoutEffectHook.jsx";
import FunctionUseLayoutEffectHookPinakinsir from "./FunctionalCompo/FunctionUseLayoutEffectHookPinakinsir.jsx";
import FunctionUseLayoutEffectuseContext from "./FunctionalCompo/FunctionUseLayoutEffectuseContext.jsx";
import FunctionUseSimpleApi from "./FunctionalCompo/FunctionUseSimpleApi.jsx";
import FunctionUseCallBack from "./FunctionalCompo/FunctionUseCallBack.jsx";
import FunctionUseMemo from "./FunctionalCompo/FunctionUseMemo.jsx";
import FunctionUseRef from "./FunctionalCompo/FunctionUseRef.jsx";
import FunctionUseReducer from "./FunctionalCompo/FunctionUseReducer.jsx";
/* import Email from "./FunctionalCompo/Email.js"; */

function Myapp() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/Contact" element={<Contact />} />
          <Route path="/Example" element={<Example />}>
            <Route path="ClassComponenet" element={<ClassComponenet />}>
              <Route path="Construct" element={<ClassComponenetConstruct />} />
              <Route path="reusableClasscompo" element={<ClassComponenetReusable />}/>
              <Route path="stateexample" element={<StateExample />} />
              <Route path="statelifecycle" element={<StateLifeCycle />} />
              <Route path="loginPage" element={<LoginPage />} />
            </Route>

            <Route path="functionalCompo" element={<FunctionalComponenet />}>
              <Route path="functionhellojsrend"element={<MixFunctionComponent />} />
              <Route path="functionprops" element={<FunctionProps />} />
              <Route path="functionstatehooks" element={<FunctionStateHooks />}/>
              <Route path="FunctionUseEffectHooks" element={<FunctionUseEffectHooks />} />
              <Route path="FunctionUseEffectHooksJa"element={<FunctionUseEffectHooksJa />} />
              <Route path="FunctionUseLayoutEffectHook"element={<FunctionUseLayoutEffectHook />}/>
              <Route path="FunctionUseLayoutEffectHookPinakinsir"element={<FunctionUseLayoutEffectHookPinakinsir />}/>
              <Route path="FunctionUseLayouteffectusecontext"element={<FunctionUseLayoutEffectuseContext />}/>
              <Route path="FunctionUsesimpleApi"element={<FunctionUseSimpleApi />}/>
              <Route path="FunctionUseCallback"element={<FunctionUseCallBack />}/>
              <Route path="Functionusememo"element={<FunctionUseMemo />}/>
              <Route path="Functionuseref"element={<FunctionUseRef />}/>
              <Route path="Functionusereducer"element={<FunctionUseReducer />}/>
                
            </Route>

            <Route path="stylecss" element={<StyleCssComponenet />}>
               <Route path="inlinecsscomponent" element={<InlineCssCompo />} />
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
      ,
    </>
  );
}

export default Myapp;
