import React, { Component } from "react";
import { Link, Outlet } from "react-router-dom";

class ClassComponenet extends Component {
  render() {
    return (
      <>
        <div className="row mt-3">
          <div className="col">
          <ul>
          <li>
            <Link to="Construct">Construct</Link>
          </li>
          <li>
            <Link to="reusableClasscompo">Reusable</Link>
          </li>
          <li>
            <Link to="stateexample">StateComp</Link>
          </li>
          <li>
            <Link to="StateLifeCycle">Life-Cycle</Link>
          </li>
          <li>
            <Link to="LoginPage">Login-page</Link>
          </li>
        </ul>
          </div>
        </div>
        <Outlet />
      </>
    );
  }
}

export default ClassComponenet;
