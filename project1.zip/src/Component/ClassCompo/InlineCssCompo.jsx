import React from 'react'


function InlineCssCompo(props) {
  return (
    <div>
      
      <div
        style={{
          textAlign: "center",
          maxWidth: "950px",
          margin: "0 auto",
          border: "1px solid #e6e6e6",
          padding: "40px 25px",
          marginTop: "50px"
        }}
      >
          Hello every-one
          </div>
    </div>
  )
}



export default InlineCssCompo

