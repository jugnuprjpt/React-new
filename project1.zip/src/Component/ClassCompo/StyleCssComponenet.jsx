import React from "react";
import { Link, Outlet } from "react-router-dom";
import styled from 'styled-components';

// Create a Title component that'll render an <h1> tag with some styles
const Title = styled.h1`
  font-size: 1.5em;
  text-align: center;
  color: palevioletred;
`;

// Create a Wrapper component that'll render a <section> tag with some styles
const Wrapper = styled.section`
  padding: 4em;
  background: papayawhip;
`;
const styles = {
    section: {
      fontFamily: "-apple-system",
      fontSize: "1rem",
      fontWeight: 1.5,
      lineHeight: 1.5,
      color: "#292b2c",
      backgroundColor: "#fff",
      padding: "0 2em"
    },
    wrapper: {
      textAlign: "center",
      maxWidth: "950px",
      margin: "0 auto",
      border: "1px solid #e6e6e6",
      padding: "40px 25px",
      marginTop: "50px"
    },
    avatar: {
      margin: "-90px auto 30px",
      width: "100px",
      borderRadius: "50%",
      objectFit: "cover",
      marginBottom: "0"
    },
    quote: {
      lineHeight: 1.5,
      fontWeight: 300,
      marginBottom: "25px",
      fontSize: "1.375rem"
    },
    name: {
      marginBottom: "0",
      fontWeight: 600,
      fontSize: "1rem"
    },
    position: { fontWeight: 400 }
  };
  const Button = styled.button`
  color: limegreen;
  border: 2px solid limegreen;
  font-size: 1em;
  margin: 2em auto ;
  padding: 0.25em 1em;
  border-radius: 3px;
  display:block;

  &:hover {
    background-color:black;
    opacity: 0.9;
  }
`;
function StyleCssComponenet() {
  return (
      
    <>
    
      <div className="row mt-3">
        <div className="col">
          <ul>
            <li>
              <Link to="inlinecsscomponent">Inline-css</Link>
            </li>
          </ul>
        </div>
        </div>
        <div className="row mt-3">
        <div className="col">
        <Wrapper>
    <Title>
      Hello World!
    </Title>
  </Wrapper>
  
        </div>
      </div>
      <section style={styles.section}>
      <div style={styles.wrapper}>
        <img
          src="https://randomuser.me/api/portraits/women/48.jpg"
          alt="Tammy Stevens"
          style={styles.avatar}
        />
        <div>
          <p style={styles.quote}>
            This is one of the best developer blogs on the planet! I read it
            daily to improve my skills.
          </p>
        </div>
        <p style={styles.name}>
          Tammy Stevens
          <span style={styles.position}> · Front End Developer</span>
        </p>
      </div>
    </section>
    <Button>Click me</Button>
      <Outlet />
    </>
  );
}

export default StyleCssComponenet;
