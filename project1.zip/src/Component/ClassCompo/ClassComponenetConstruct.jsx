import React, { Component } from 'react';

class ClassComponenetConstruct extends Component {
    constructor (props){
       super(props);
    }
    render() {
        return (
            <>
                Constructor is method which is invoked by default when componenet intilized
            </>
        );
    }
}

export default ClassComponenetConstruct;