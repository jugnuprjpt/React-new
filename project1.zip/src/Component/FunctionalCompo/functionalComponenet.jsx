import React from "react";
import { Link, Outlet } from "react-router-dom";
import "./Custom.css";

function functionalComponenet(props) {
  return (
    <>
       <div className="row ">
        <div className="col "> 
 
       <ul>
        <li className="hoverme">
          <Link to="functionhellojsrend ">Jsx-Hello-Rendering</Link>
          <ul className="child">
            <li className="hoverme">
             <Link to="functionhellojsrend ">child-menu</Link> 
             {/*  <ul className="child">
                <li>
                  <Link to="functionhellojsrend ">Grand-child</Link>
                </li>
              </ul> */}
            </li>
            <li>test2</li>
          </ul>
        </li>
      </ul>  
       </div>
      </div> 
            <ul>
                <li>
                <Link to="functionhellojsrend ">Jsx-Hello-Rendering</Link>
                </li>
              
                <li>
                  <Link to="FunctionProps ">Function-Props</Link>
                </li>
                <li>
                  <Link to="FunctionStateHooks">Function-State-Hooks</Link>
                </li>
                <li>
                  <Link to="FunctionUseEffectHooks">Function-Use-effect</Link>
                </li>
                <li>
                  <Link to="FunctionUseEffectHooksJa">Function-Use-effect-Ja</Link>
                </li>
                <li>
                  <Link to="FunctionUseLayoutEffectHook">Function-Use-Layout-Effect</Link>
                </li>
                <li>
                  <Link to="FunctionUseLayoutEffectHookPinakinsir">FunctionUseLayoutEffectHook-Pinakinsir</Link>
                </li>
                <li>
                  <Link to="FunctionUseLayouteffectusecontext">FunctionUseLayoutEffect-useContext</Link>
                </li>
                <li>
                  <Link to="FunctionUseSimpleApi">FunctionUse-Simple-Api</Link>
                </li>
                <li>
                  <Link to="FunctionUseCallback">FunctionUse-CallBack</Link>
                </li>
                <li>
                  <Link to="Functionusememo">Function-UseMemo</Link>
                </li>
                <li>
                  <Link to="Functionuseref">Function-UseRef</Link>
                </li>
                <li>
                  <Link to="Functionusereducer">Function-UseReducer</Link>
                </li>
               
               
               
               
              </ul>
      <Outlet />
    </>
  );
}

export default functionalComponenet;
