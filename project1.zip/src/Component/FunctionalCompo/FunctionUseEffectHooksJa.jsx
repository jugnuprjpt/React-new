import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";



function FunctionUseEffectHooksJa(props) {

  /* var ResData="abcd" */
  const [data, setData] = useState();
  const [AddnewRec, setAddnewRec] = useState(1);
  const [loader, setLoader] = useState(true);

  console.log(data);

  useEffect(() => {
    // console.log("Innser useEffect");
    fetch("https://reqres.in/api/users?page=2")
      .then((res) => res.json())
      .then((Responce) => {
        const ResData = Object.entries(Responce).map((val, index) => {
        
        
         return (
        <>
          <tr key={index}>
        <td> {val[1].email} </td>
               
           </tr>
           </>
         );
         });
    setData(ResData);
    setLoader(false) ;
    
         });     
     
  }, [AddnewRec]);
  const newrecord = () => {
    setAddnewRec(2);
  };


  return (
    <>
      {loader}
      {loader ? (
        <>
        <img src="./../../logo512.png" alt="" />
        </>
      ):(
        <table>
          <thead>
            <tr>
              <th>email</th>
            </tr>
          </thead>
          <tbody>
            {data}
          </tbody>
        </table>
      )}

      <button onClick={newrecord}>Add</button> 
      {AddnewRec} 
      
    </>
  );
}

export default FunctionUseEffectHooksJa;
