import React, { useEffect, useState } from "react";

let cdata;
function FunctionUseLayoutEffectHookPinakinsir() {
  const [data, setData] = useState();
  useEffect(() => {
    fetch("https://reqres.in/api/users?page=2")
      .then((res) => res.json())
      .then((resData) => {
        setData(resData.data);
        console.log(data);
      })
      .catch((er) => console.log(er));
  }, []);

  return (
    <>
      {
        <table border="1">
          <tr>
            <td>Emails</td>
            <td>First Name</td>
            <td>Last Name</td>
          </tr>
          {data?.map((d) => (
            <tr key={d.id}>
              <td>{d.email}</td>
              <td>{d.first_name}</td>
              <td>{d.last_name}</td>
            </tr>
          ))}
        </table>
      }
    </>
  );
}

export default FunctionUseLayoutEffectHookPinakinsir;
