import React, { useEffect } from "react";

var data;
function FunctionUseEffectHooks() {
  // const [loader, setLoader] = useState();

  useEffect(() => {
    fetch("https://reqres.in/api/users?page=2").then((req) => {
      req.json().then((res) => {
        data = res.data;
        // console.log(res.data);
        // console.log(Data);
      });
    });
  }, []);

  return (
    <>
       <div >
      <table>
        {data?.map((item) => (
          <tr>
            <td>
              <img src={item.avatar} alt=""  />
            </td>
            <td>{item.email}</td>
          </tr>
        ))}
      </table>
      </div>
    </>
  );
}

export default FunctionUseEffectHooks;
