import React,{useRef, useState} from 'react'
import PropTypes from 'prop-types'

function FunctionUseRef(props) {
    const [message,setMessage]=useState()
    const [data,setData]=useState([])
    const lists= [...Array(8).keys()];
    /* const inputEl = useRef(null); */
    const inputRef= useRef([]);
    const handler = idx => e => {
   const next =inputRef.current[idx+1];
   setData(idx+1);
    };
  return (
    <div>
    <input onChange={(e)=>{setMessage(e.target.value)}} value={message}  name="username" type="text"/>
      {message}
      { lists.map((x,index)=>(
          <div key={x}>
              <input 
              key={x}
              ref={e1=>inputRef.current[x]=e1}
              onChange={handler(x)}
              type="number"
              className='otp_box'
              />
              </div>
              ))}
             {data} 
               </div>
               
      );

      }
      
  




export default FunctionUseRef

