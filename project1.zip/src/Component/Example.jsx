import React from 'react';
import Header from './Header';
import { Link, Outlet } from "react-router-dom";

function Example(props) {
    return (
        <>
           <Header/>
           <div className="container">
               <div className="row mt-5">
                   <div className="col">
                   <Link to= "Classcomponenet">Class-componenet</Link>
                   </div>
                   <div className="col">
                   <Link to= "functionalcompo">Function-componenet</Link>
                   </div>     
                   <div className="col">
                   <Link to="stylecss">Style-Componenet</Link>
                   </div>            
               </div>
               <Outlet />
           </div>

        </>
    );
}

export default Example;