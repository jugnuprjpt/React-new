import React from 'react'
import { Link } from 'react-router-dom'
import AboutUs from '../Header/AboutUs'
import Header from '../Header/Header'


const Health = () => {
  return (
    <>
    <AboutUs></AboutUs>
    <Link to ="/AboutUs"> clickme </Link>
      <Header></Header>

      
    </>
  )
}

export default Health
