import React from 'react'
import Header from '../Header/Header'

const Private = () => {
  return (
    <>
    <Header></Header>
      
    </>
  )
}

export default Private
