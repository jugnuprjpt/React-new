import React from 'react'
import Header from '../Header/Header'

const Travel = () => {
  return (
    <>
      {/* <Header></Header> */}
    </>
  )
}

export default Travel
