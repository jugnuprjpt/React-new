import React from 'react'
import Header from '../Header/Header'

const Commercial = () => {
  return (
    <>
      <Header></Header>
    </>
  )
}

export default Commercial
