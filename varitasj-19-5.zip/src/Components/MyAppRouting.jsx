import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Private from "./Home/Private";
import Health  from "./Home/Health.jsx"
import Bike  from "./Home/Bike.jsx"
import Commercial from "./Home/Commercial.jsx"
import Travel from "./Home/Travel.jsx"
import Home from "./Home/Home";
import AboutUs from "./Header/AboutUs.jsx"



function MyAppRouting() {
  return (
    <>
    <BrowserRouter>
        <Routes> 
         <Route path="/" element={<Home/>} />
         <Route path="Private" element={<Private/>} />
         <Route path="/Health" element={<Health/>} >
             <Route path="AboutUs" element={<AboutUs/>} />
         </Route>
        {/*  <Route path="Bike" element={<Bike/>} />
         <Route path="Commercial" element={<Commercial/>} />
         <Route path="Travel" element={<Travel/>} /> */}
        
       </Routes>
      </BrowserRouter>
      
    </>
  );
}

export default MyAppRouting;
