import React from 'react'
import Header from './Header'
import { Outlet } from 'react-router'
import { Link } from 'react-router-dom'

const AboutUs = () => {
  return (
      
    <>
      <div>Hekllo</div>
      
    </>
  )
}

export default AboutUs