import './App.css';


import MyAppRouting from './Components/MyAppRouting';

function App() {
  return (
    <div className="App">
       
       <MyAppRouting></MyAppRouting>
 
       
    </div>
  );
}

export default App;
